package sessionPool

import (
	"fmt"
	"github.com/apache/iotdb-client-go/client"
	"iotdb-monitor/config"
	"log"
)

var sessionPool client.SessionPool

func Init(commonConfig config.Config) {
	poolConfig := &client.PoolConfig{
		Host:     commonConfig.ServiceAddress,
		Port:     commonConfig.ServicePort,
		UserName: "root",
		Password: "root",
	}

	sessionPool = client.NewSessionPool(poolConfig, 3, 60000, 60000, false)
}

func ExecuteFlush() {
	sql := "flush"
	session, err := sessionPool.GetSession()
	defer sessionPool.PutBack(session)
	if err != nil {
		panic(fmt.Errorf("session pool get session err:%v", err))
	}

	sessionDataSet, flushErr := session.ExecuteStatement(sql)
	if flushErr != nil {
		panic(fmt.Errorf("session pool execute query err:%v", flushErr))
	}
	log.Println("session pool execute FLUSH success")
	sessionDataSet.Close()
}
