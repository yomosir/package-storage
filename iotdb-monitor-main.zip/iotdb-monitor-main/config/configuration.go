package config

import (
	"github.com/spf13/viper"
	"log"
)

type Config struct {
	MonitorAddress string
	ExporterPort   string
	Inverter       int
	ServiceAddress string
	ServicePort    string
}

func Reader() *Config {
	viper.AutomaticEnv()
	viper.SetConfigName("config")
	viper.AddConfigPath(".")
	viper.SetConfigType("yaml")
	if err := viper.ReadInConfig(); err != nil {
		log.Printf("读取配置配置文件异常")
		log.Fatal(err)
	}
	viper.BindEnv("IoTDB.monitor_address", "monitor_address")
	viper.BindEnv("exporter.port", "exporter_port")
	viper.BindEnv("inverter", "inverter")
	viper.BindEnv("IoTDB.service_address", "service_address")
	viper.BindEnv("IoTDB.service_port", "service_port")
	return &Config{
		MonitorAddress: viper.GetString("IoTDB.monitor_address"),
		ExporterPort:   viper.GetString("exporter.port"),
		Inverter:       viper.GetInt("interval"),
		ServiceAddress: viper.GetString("IoTDB.service_address"),
		ServicePort:    viper.GetString("IoTDB.service_port"),
	}
}
