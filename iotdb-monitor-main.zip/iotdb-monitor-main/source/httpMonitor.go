package source

import (
	"encoding/json"
	"fmt"
	"log"
)

/**
{
    "version": "3.1.3",
    "gauges": {
        "iot-metrics.cores": {
            "value": 16
        },
        "iot-metrics.cpu_ratio": {
            "value": 23
        },
        "iot-metrics.freePhysical_memory": {
            "value": 4899
        },
        "iot-metrics.free_memory": {
            "value": 1459
        },
        "iot-metrics.host": {
            "value": "server89"
        },
        "iot-metrics.max_memory": {
            "value": 5461
        },
        "iot-metrics.port": {
            "value": 8181
        },
        "iot-metrics.totalPhysical_memory": {
            "value": 64276
        },
        "iot-metrics.total_memory": {
            "value": 2475
        },
        "iot-metrics.usedPhysical_memory": {
            "value": 59377
        }
    },
    "counters": {

    },
    "histograms": {

    },
    "meters": {

    },
    "timers": {

    }
}
*/

/**
用作json
*/

type ResponseInfo struct {
	Version string `json:"version"`
	Gauges  Gauges `json:"gauges"`
}

type Gauges struct {
	Cores          NumberValue `json:"iot-metrics.cores"`
	CpuRatio       NumberValue `json:"iot-metrics.cpu_ratio"`
	FreePhyMemory  NumberValue `json:"iot-metrics.freePhysical_memory"`
	FreeMemory     NumberValue `json:"iot-metrics.free_memory"`
	Host           StringValue `json:"iot-metrics.host"`
	MaxMemory      NumberValue `json:"iot-metrics.max_memory"`
	Port           NumberValue `json:"iot-metrics.port"`
	TotalPhyMemory NumberValue `json:"iot-metrics.totalPhysical_memory"`
	TotalMemory    NumberValue `json:"iot-metrics.total_memory"`
	UsedPhyMemory  NumberValue `json:"iot-metrics.usedPhysical_memory"`
}

type StringValue struct {
	Value string `json:"value"`
}

type NumberValue struct {
	Value float64 `json:"value"`
}

func DataGet(address string) *Gauges {
	// 从接口获取相关数据，具体结构见上方注释
	fullPath := address + "/json"
	c := getHttp(fullPath)
	resp, err := c.Get(fullPath)
	if err != nil {
		panic(fmt.Errorf("获取json数据失败 ,ERROR: %w \n", err))
	}
	defer resp.Body.Close()
	responseInfo := new(ResponseInfo)
	if parseError := json.NewDecoder(resp.Body).Decode(responseInfo); parseError != nil {
		log.Fatalln(parseError)
	}
	log.Println(responseInfo.Version)
	return &responseInfo.Gauges
}
