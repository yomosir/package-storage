package source

import (
	"container/list"
	"fmt"
	"github.com/PuerkitoBio/goquery"
)

type SqlRow struct {
	OperationType string
	StartTime     string
	FinishTime    string
	ExecDuration  string
	Statement     string
	State         string
}

// HtmlGet /*
func HtmlGet(url string) *list.List {
	c := getHttp(url)
	resp, error := c.Get(url)
	if error != nil {
		panic(fmt.Errorf("fatal error config file: %w", error))
	}
	defer resp.Body.Close()
	doc, parseErr := goquery.NewDocumentFromReader(resp.Body)
	if parseErr != nil {
		panic(fmt.Errorf("parse error: %w", parseErr))
	}
	sqlRows := list.New()
	findSql(doc, sqlRows)
	return sqlRows
}

/*
*
在页面元素中寻找SQL对应的table并转换成对应结构体
*/
func findSql(n *goquery.Document, sqlRows *list.List) {
	n.Find("tr").Each(func(i int, s *goquery.Selection) {
		if s.Parent().Is("tbody") {
			// 如果tr的父节点是tbody，则获取其中的SQL信息
			oneRow := new(SqlRow)
			s.Children().Each(func(i int, s *goquery.Selection) {
				content := s.Text()
				setPosToRow(content, i, oneRow)
			})
			sqlRows.PushBack(oneRow)
		}
	})
}

func setPosToRow(value string, pos int, row *SqlRow) {
	switch pos {
	case 0:
		row.OperationType = value
	case 1:
		row.StartTime = value
	case 2:
		row.FinishTime = value
	case 3:
		row.ExecDuration = value
	case 4:
		row.Statement = value
	case 5:
		row.State = value
	}
}
