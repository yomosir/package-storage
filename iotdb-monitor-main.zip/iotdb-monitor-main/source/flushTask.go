package source

import (
	"iotdb-monitor/config"
	"iotdb-monitor/sessionPool"
	"log"
	"sync"
	"time"
)

var mapMutex sync.Mutex
var memoryMap = make(map[int64]float64)
var lastFlushTime int64 = 0

func FlushTask(commonConfig config.Config) {
	go func() {
		for {
			performTask(commonConfig)
			time.Sleep(5 * time.Minute)
		}
	}()
}

func performTask(commonConfig config.Config) {
	memoryData := DataGet(commonConfig.MonitorAddress)
	currentTime := time.Now().Unix()
	currentMemory := memoryData.TotalMemory.Value
	mapMutex.Lock()
	defer mapMutex.Unlock()
	var lastMemory float64
	if len(memoryMap) > 0 {
		var lastTimestamp int64
		for timestamp := range memoryMap {
			if timestamp > lastTimestamp {
				lastTimestamp = timestamp
			}
		}
		lastMemory = memoryMap[lastTimestamp]
	}

	if lastMemory > 0 && float64(currentMemory)/lastMemory > 1.2 {
		if currentTime-lastFlushTime >= 3600 {
			log.Println("reach threshold, start flush task : %d, TotalJVMMemory : %d \n", currentTime, currentMemory)
			sessionPool.ExecuteFlush()
			lastFlushTime = currentTime
		} else {
			log.Println("flush operation skipped due to 1-hour cooldown.")
		}
	}
	memoryMap[currentTime] = currentMemory
}
