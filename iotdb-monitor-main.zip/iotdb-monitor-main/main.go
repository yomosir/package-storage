package main

import (
	"fmt"
	"iotdb-monitor/config"
	"iotdb-monitor/exporter"
	"iotdb-monitor/sessionPool"
	"iotdb-monitor/source"
)

var commonConfig config.Config
var memoryData source.Gauges

func main() {
	commonConfig = *config.Reader()
	fmt.Println(commonConfig.MonitorAddress)
	fmt.Println(commonConfig.ExporterPort)
	fmt.Println(commonConfig.Inverter)
	sessionPool.Init(commonConfig)
	source.FlushTask(commonConfig)
	exporter.Exporter(commonConfig)
}
