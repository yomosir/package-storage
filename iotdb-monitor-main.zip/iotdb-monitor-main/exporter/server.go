package exporter

import (
	"fmt"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"iotdb-monitor/config"
	"iotdb-monitor/source"
	"log"
	"net/http"
	"time"
)

func Exporter(commonConfig config.Config) {
	m := NewMetrics()
	flushMetrics(m, commonConfig)
	http.Handle("/metrics", promhttp.Handler())
	err := http.ListenAndServe(":"+commonConfig.ExporterPort, nil)
	if err != nil {
		panic(fmt.Errorf("exporter start error: %v", err))
	}
}

type metrics struct {
	CpuCores        *prometheus.GaugeVec
	JvmMemory       *prometheus.GaugeVec
	HostMemory      *prometheus.GaugeVec
	SqlOperatorType *prometheus.CounterVec
}

func NewMetrics() *metrics {
	m := &metrics{
		CpuCores: promauto.NewGaugeVec(prometheus.GaugeOpts{
			Name: CORES,
			Help: "sever total cpu cores",
		}, []string{"name"}),
		JvmMemory: promauto.NewGaugeVec(prometheus.GaugeOpts{
			Name: APPLICATION_MEMORY,
			Help: "IoTDB application memory info",
		}, []string{"name"}),
		HostMemory: prometheus.NewGaugeVec(prometheus.GaugeOpts{
			Name: SERVER_HOST_MEMORY,
			Help: "IoTDB server memory info",
		}, []string{"name"}),
		SqlOperatorType: prometheus.NewCounterVec(prometheus.CounterOpts{
			Name: SQL_OPERATOR_TYPE,
			Help: "different operation IoTDB SQL exec counter",
		}, []string{"name"}),
	}
	return m
}

func flushMetrics(customeMetrics *metrics, commonConfig config.Config) {
	go func() {
		for {
			start := time.Now()
			log.Print("start time to flush metrics", start)
			log.Print("start to search data")
			memoryData := *source.DataGet(commonConfig.MonitorAddress)
			customeMetrics.CpuCores.With(prometheus.Labels{"name": CORES}).Set(memoryData.Cores.Value)
			customeMetrics.CpuCores.With(prometheus.Labels{"name": CPU_RATIO}).Set(memoryData.CpuRatio.Value)
			customeMetrics.JvmMemory.With(prometheus.Labels{"name": MAX_MEMORY}).Set(memoryData.MaxMemory.Value)
			customeMetrics.JvmMemory.With(prometheus.Labels{"name": TOTAL_MEMORY}).Set(memoryData.TotalMemory.Value)
			customeMetrics.JvmMemory.With(prometheus.Labels{"name": FREE_MEMORY}).Set(memoryData.FreeMemory.Value)
			customeMetrics.HostMemory.With(prometheus.Labels{"name": USED_PHY_MEMORY}).Set(memoryData.UsedPhyMemory.Value)
			customeMetrics.HostMemory.With(prometheus.Labels{"name": TOTAL_PHY_MEMORY}).Set(memoryData.TotalPhyMemory.Value)
			customeMetrics.HostMemory.With(prometheus.Labels{"name": FREE_PHY_MEMORY}).Set(memoryData.FreePhyMemory.Value)
			sqlRows := source.HtmlGet(commonConfig.MonitorAddress)
			for row := sqlRows.Front(); row != nil; row = row.Next() {
				sqlRow := row.Value.(*source.SqlRow)
				customeMetrics.SqlOperatorType.With(prometheus.Labels{"name": sqlRow.OperationType}).Inc()
			}
			duration := time.Duration(commonConfig.Inverter) * time.Second
			log.Println("finish to flush metrics")
			time.Sleep(duration)
		}
	}()
}
