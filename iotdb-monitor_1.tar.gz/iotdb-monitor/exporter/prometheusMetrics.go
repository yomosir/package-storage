package exporter

// metric name
// cpu核心相关指标
const CPU_CORE = "cpu_core"

// 应用内存相关指标
const APPLICATION_MEMORY = "application_memory"

// 服务器内存相关指标
const SERVER_HOST_MEMORY = "server_host_memory"

// sql 操作类型
const SQL_OPERATOR_TYPE = "sql_operator_type"

// count vec 类型的统计指标
// SQL 操作类型
const OPERATOR_TYPE string = "operator_type"

// guage 类型指标
const CORES string = "cores"
const CPU_RATIO string = "cpu_ratio"
const FREE_PHY_MEMORY string = "free_phy_memory"
const FREE_MEMORY string = "free_memory"
const MAX_MEMORY string = "max_memory"
const TOTAL_PHY_MEMORY string = "total_phy_memory"
const TOTAL_MEMORY string = "total_memory"
const USED_PHY_MEMORY string = "used_phy_memory"
