package source

import (
	"crypto/tls"
	"net/http"
	"strings"
)

func getHttp(url string) *http.Client {
	c := &http.Client{}
	if strings.Contains(url, "https") {
		tr := &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		}
		c = &http.Client{Transport: tr}
	}
	return c
}
